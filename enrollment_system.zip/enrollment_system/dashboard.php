<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Student Dashboard</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f5f6fa;
      background: url('img/bg.jpg') no-repeat center center fixed;
      background-size: cover;
    }

    /* Navbar styles */
    .navbar {
      background-color: #2f3640;
      padding: 15px;
      display: flex;
      justify-content: center;
      gap: 30px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    .navbar a {
      color: #f5f6fa;
      text-decoration: none;
      font-weight: bold;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .navbar a:hover {
      background-color: #40739e;
    }

    /* Image container styles */
    .centered-image {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 40px;
    }

    .centered-image img {
      max-width: 90%;
      height: auto;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }
  </style>
</head>
<body>
  <nav class="navbar">
  <a href="profile.php">Profile</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="enroll.php">Enroll</a>
  <a href="logout.php">Logout</a>
</nav>


  <div class="centered-image">
    <img src="img/EP.jpg" alt="Enrollment Poster">
  </div>

</body>
</html>
