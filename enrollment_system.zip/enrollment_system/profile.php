<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "enrollment_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$studentID = $_SESSION['student_id'];
$query = "SELECT * FROM profiles WHERE student_number = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $studentID);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Student Profile</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: url('bg.jpg') no-repeat center center fixed;
      background-size: cover;
    }

    .navbar {
      background-color: #2f3640;
      padding: 15px;
      display: flex;
      justify-content: center;
      gap: 30px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    .navbar a {
      color: #f5f6fa;
      text-decoration: none;
      font-weight: bold;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .navbar a:hover {
      background-color: #40739e;
    }

    .profile-container {
      display: flex;
      justify-content: center;
      margin-top: 60px;
    }

    .profile-card {
      background-color: rgba(255, 255, 255, 0.95);
      padding: 30px;
      width: 500px;
      border-radius: 15px;
      text-align: center;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
    }

    .profile-card img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      border: 4px solid #2f3640;
      margin-bottom: 20px;
    }

    .profile-card h2 {
      margin: 10px 0;
      font-size: 24px;
      color: #2f3640;
    }

    .profile-card p {
      font-size: 16px;
      margin: 8px 0;
      color: #333;
    }

    .profile-card strong {
      color: #2f3640;
    }
  </style>
</head>
<body>

<nav class="navbar">
  <a href="profile.php">Profile</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="enroll.php">Enroll</a>
  <a href="logout.php">Logout</a>
</nav>

<div class="profile-container">
  <div class="profile-card">
    <img src="<?= htmlspecialchars($student['profile_pic'] ?? 'img/id.jpg') ?>" alt="Profile Picture">
    <h2><?= htmlspecialchars($student['first_name'] . ' ' . $student['middle_name'] . ' ' . $student['surname']) ?></h2>
    <p><strong>Student ID:</strong> <?= htmlspecialchars($student['student_number']) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($student['email']) ?></p>
    <p><strong>Birthday:</strong> <?= htmlspecialchars($student['birthday']) ?></p>
    <p><strong>Age:</strong> <?= htmlspecialchars($student['age']) ?></p>
    <p><strong>Sex:</strong> <?= htmlspecialchars($student['sex']) ?></p>
  </div>
</div>

</body>
</html>
