<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "enrollment_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageClass = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $courseID = $_POST['course_id'];
    $semester = $_POST['semester'];
    $academicYear = $_POST['academic_year'];
    $studentID = $_SESSION['student_id'];

    $stmt = $conn->prepare("INSERT INTO ENROLLMENT (StudentID, CourseID, Semester, AcademicYear) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $studentID, $courseID, $semester, $academicYear);
    
    if ($stmt->execute()) {
        $message = "✅ Partial enrollment successful. You will be contacted via email and asked to visit the office to select your subjects and settle your payment at the cashier. This secures your enrollment slot for the selected semester and academic year.";

        $messageClass = "success";
    } else {
        $message = "❌ Enrollment failed: " . $conn->error;
        $messageClass = "error";
    }
}

$courses = $conn->query("SELECT CourseID, CourseName FROM COURSE");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Student Enrollment</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f0f2f5;
      background: url('bg.jpg') no-repeat center center fixed;
    }

    .navbar {
      background-color: #2f3640;
      padding: 15px;
      display: flex;
      justify-content: center;
      gap: 30px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }

    .navbar a {
      color: #f5f6fa;
      text-decoration: none;
      font-weight: bold;
      padding: 10px 20px;
      border-radius: 5px;
      transition: background 0.3s;
    }

    .navbar a:hover {
      background-color: #40739e;
    }

    .enrollment-container {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      padding: 40px 20px;
    }

    .enrollment-card {
      background-color: #ffffff;
      border-radius: 12px;
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
      padding: 30px;
      width: 100%;
      max-width: 450px;
    }

    h2 {
      text-align: center;
      color: #2f3640;
      margin-bottom: 20px;
    }

    label {
      font-weight: bold;
      color: #2f3640;
      display: block;
      margin-top: 15px;
    }

    select, input[type="text"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      margin-top: 5px;
      box-sizing: border-box;
    }

    button {
      width: 100%;
      padding: 12px;
      margin-top: 20px;
      background-color: #40739e;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    button:hover {
      background-color: #273c75;
    }

    .message {
      margin-top: 20px;
      text-align: center;
      padding: 10px;
      border-radius: 6px;
    }

    .success {
      background-color: #dff9fb;
      color: #27ae60;
      border: 1px solid #27ae60;
    }

    .error {
      background-color: #ffcccc;
      color: #c0392b;
      border: 1px solid #c0392b;
    }
  </style>
</head>
<body>

  <nav class="navbar">
  <a href="profile.php">Profile</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="enroll.php">Enroll</a>
  <a href="logout.php">Logout</a>
</nav>


  <div class="enrollment-container">
    <div class="enrollment-card">
      <h2> Pre-Enroll</h2>

      <?php if (!empty($message)): ?>
        <div class="message <?= $messageClass ?>"><?= $message ?></div>
      <?php endif; ?>

      <form method="POST">
        <label for="course_id">Select Course: <br> (You must select your course or it will be invalid.)</label>
        <select name="course_id" required>
          <?php while ($row = $courses->fetch_assoc()) {
              echo "<option value='{$row['CourseID']}'>{$row['CourseName']}</option>";
          } ?>
        </select>

        <label for="semester">Semester:</label>
        <input type="text" name="semester" placeholder="e.g. 1st, 2nd" required>

        <label for="academic_year">Academic Year:</label>
        <input type="text" name="academic_year" placeholder="e.g. 2024-2025" required>

        <button type="submit">Enroll Now</button>
      </form>
    </div>
  </div>

</body>
</html>

<?php
$conn->close();
?>
