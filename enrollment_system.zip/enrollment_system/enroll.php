<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "enrollment_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageClass = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $courseID = $_POST['course_id'];
    $semester = $_POST['semester'];
    $academicYear = $_POST['academic_year'];
    $studentID = $_SESSION['student_id'];

    $stmt = $conn->prepare("INSERT INTO ENROLLMENT (StudentID, CourseID, Semester, AcademicYear) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $studentID, $courseID, $semester, $academicYear);

    if ($stmt->execute()) {
        $enrollmentID = $conn->insert_id;

        $insertSubject = $conn->prepare("INSERT INTO ENROLLMENT_SUBJECTS (enrollment_id, subject_id) VALUES (?, ?)");
        $insertSubject->bind_param("ii", $enrollmentID, $subjectID);

        for ($i = 1; $i <= 8; $i++) {
            if (!empty($_POST["subject$i"])) {
                $subjectID = $_POST["subject$i"];
                $insertSubject->execute();
            }
        }

        $message = "✅ Enrollment completed successfully. Please proceed to the Accounting Office to obtain your Official Enrollment Form.";
        $messageClass = "success";
    } else {
        $message = "❌ Enrollment failed: " . $conn->error;
        $messageClass = "error";
    }
}

$courses = $conn->query("SELECT CourseID, CourseName FROM COURSE");
$subjects = $conn->query("SELECT subject_id, subject_name FROM SUBJECTS");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Enrollment</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f0f2f5;
            background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .navbar {
            background-color: #2f3640;
            padding: 15px;
            display: flex;
            justify-content: center;
            gap: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .navbar a {
            color: #f5f6fa;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .navbar a:hover {
            background-color: #40739e;
        }

        .enrollment-container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 20px;
        }

        .enrollment-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            padding: 30px 30px 40px;
            width: 100%;
            max-width: 900px;
            box-sizing: border-box;
        }

        h2 {
            text-align: center;
            color: #2f3640;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #2f3640;
            display: block;
            margin-top: 15px;
        }

        select,
        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-top: 5px;
            box-sizing: border-box;
            background-color: #f9f9f9;
        }

        select:focus,
        input[type="text"]:focus {
            border-color: #40739e;
            outline: none;
            background-color: #fff;
        }

        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px 30px;
            margin-top: 10px;
        }

        .subjects-grid div {
            display: flex;
            flex-direction: column;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 25px;
            background-color: #40739e;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #273c75;
        }

        .message {
            margin-top: 20px;
            text-align: center;
            padding: 12px 15px;
            border-radius: 6px;
            font-size: 14px;
            box-sizing: border-box;
        }

        .success {
            background-color: #dff9fb;
            color: #27ae60;
            border: 1px solid #27ae60;
        }

        .error {
            background-color: #ffcccc;
            color: #c0392b;
            border: 1px solid #c0392b;
        }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="profile.php">Profile</a>
    <a href="dashboard.php">Dashboard</a>
    <a href="enroll.php">Enroll</a>
    <a href="logout.php">Logout</a>
</nav>

<div class="enrollment-container">
    <div class="enrollment-card">
        <h2>Enroll</h2>

        <?php if (!empty($message)): ?>
            <div class="message <?= htmlspecialchars($messageClass) ?>"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Course:</label>
            <input type="text" name="course_name" value="Bachelor of Science in Information Technology" readonly>
            <input type="hidden" name="course_id" value="1">

            <div class="subjects-grid">
                <?php
                $subjectOptions = "";
                if ($subjects && $subjects->num_rows > 0) {
                    while ($row = $subjects->fetch_assoc()) {
                        $sid = htmlspecialchars($row['subject_id']);
                        $sname = htmlspecialchars($row['subject_name']);
                        $subjectOptions .= "<option value='$sid'>$sname</option>";
                    }
                }

                for ($i = 1; $i <= 8; $i++) {
                    echo "<div>";
                    echo "<label for='subject$i'>Subject $i:</label>";
                    echo "<select name='subject$i' id='subject$i' required>";
                    echo "<option value=''>-- Select Subject --</option>";
                    echo $subjectOptions;
                    echo "</select>";
                    echo "</div>";
                }
                ?>
            </div>

            <label for="semester">Semester:</label>
            <input type="text" name="semester" placeholder="e.g. 1st, 2nd" required>

            <label for="academic_year">Academic Year:</label>
            <input type="text" name="academic_year" placeholder="e.g. 2024-2025" required>

            <button type="submit">Enroll Now</button>
        </form>
    </div>
</div>

<script>
// Prevent selecting the same subject more than once
const selects = document.querySelectorAll("select[name^='subject']");
selects.forEach(select => {
    select.addEventListener("change", () => {
        const selectedValues = new Set();
        let duplicates = false;

        selects.forEach(s => {
            if (s.value) {
                if (selectedValues.has(s.value)) {
                    duplicates = true;
                    s.value = "";
                } else {
                    selectedValues.add(s.value);
                }
            }
        });

        if (duplicates) {
            alert("You cannot select the same subject more than once.");
        }
    });
});
</script>

</body>
</html>

<?php $conn->close(); ?>
