<?php
$conn = new mysqli("localhost", "root", "", "enrollment_system_1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$messageClass = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $studentID = $_POST['student_id'];

    $checkStudent = $conn->prepare("SELECT student_id FROM STUDENTS WHERE student_id = ?");
    $checkStudent->bind_param("i", $studentID);
    $checkStudent->execute();
    $checkStudent->store_result();

    if ($checkStudent->num_rows === 0) {
        $insertStudent = $conn->prepare("INSERT INTO STUDENTS (student_id) VALUES (?)");
        $insertStudent->bind_param("i", $studentID);
        $insertStudent->execute();
    }

    $firstName = $_POST['first_name'];
    $middleName = !empty($_POST['middle_name']) ? $_POST['middle_name'] : null;
    $lastName = $_POST['last_name'];
    $email = $_POST['email'];
    $contactNumber = $_POST['contact_number'];

    $checkProfile = $conn->prepare("SELECT profile_id FROM PROFILES WHERE student_id = ?");
    $checkProfile->bind_param("i", $studentID);
    $checkProfile->execute();
    $checkProfile->store_result();

    if ($middleName === null) {
        if ($checkProfile->num_rows > 0) {
            $updateProfile = $conn->prepare("UPDATE PROFILES SET first_name = ?, middle_name = NULL, last_name = ?, email = ?, contact_number = ? WHERE student_id = ?");
            $updateProfile->bind_param("ssssi", $firstName, $lastName, $email, $contactNumber, $studentID);
            $updateProfile->execute();
        } else {
            $insertProfile = $conn->prepare("INSERT INTO PROFILES (student_id, first_name, middle_name, last_name, email, contact_number) VALUES (?, ?, NULL, ?, ?, ?)");
            $insertProfile->bind_param("issss", $studentID, $firstName, $lastName, $email, $contactNumber);
            $insertProfile->execute();
        }
    } else {
        if ($checkProfile->num_rows > 0) {
            $updateProfile = $conn->prepare("UPDATE PROFILES SET first_name = ?, middle_name = ?, last_name = ?, email = ?, contact_number = ? WHERE student_id = ?");
            $updateProfile->bind_param("sssssi", $firstName, $middleName, $lastName, $email, $contactNumber, $studentID);
            $updateProfile->execute();
        } else {
            $insertProfile = $conn->prepare("INSERT INTO PROFILES (student_id, first_name, middle_name, last_name, email, contact_number) VALUES (?, ?, ?, ?, ?, ?)");
            $insertProfile->bind_param("isssss", $studentID, $firstName, $middleName, $lastName, $email, $contactNumber);
            $insertProfile->execute();
        }
    }

    $courseID = $_POST['course_id'];
    $semester = $_POST['semester'];
    $academicYear = $_POST['academic_year'];

    $stmt = $conn->prepare("INSERT INTO ENROLLMENT (StudentID, CourseID, Semester, AcademicYear) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $studentID, $courseID, $semester, $academicYear);

    if ($stmt->execute()) {
        $enrollmentID = $conn->insert_id;

        $insertSubject = $conn->prepare("INSERT INTO ENROLLMENT_SUBJECTS (enrollment_id, subject_id) VALUES (?, ?)");
        $insertSubject->bind_param("ii", $enrollmentID, $subjectID);

        for ($i = 1; $i <= 8; $i++) {
            if (!empty($_POST["subject$i"])) {
                $subjectID = $_POST["subject$i"];
                $insertSubject->execute();
            }
        }

        $message = "✅ Enrollment completed successfully. Please proceed to the Accounting Office to obtain your Official Enrollment Form.";
        $messageClass = "success";

    } else {
        $message = "❌ Enrollment failed: " . $conn->error;
        $messageClass = "error";
    }
}

$courses = $conn->query("SELECT CourseID, CourseName FROM COURSE");
$subjects = $conn->query("SELECT subject_id, subject_name FROM SUBJECTS");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Enrollment</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: url('img/bg.jpg') no-repeat center center fixed;
            background-size: cover;
        }

        .navbar {
            background-color: #2f3640;
            padding: 15px;
            display: flex;
            justify-content: center;
            gap: 30px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .navbar a {
            color: #f5f6fa;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .navbar a:hover {
            background-color: #40739e;
        }

        .enrollment-container {
            display: flex;
            justify-content: center;
            padding: 40px 20px;
        }

        .enrollment-card {
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            padding: 30px;
            width: 100%;
            max-width: 900px;
            box-sizing: border-box;
            position: relative;
        }

        h2 {
            text-align: center;
            color: #2f3640;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #2f3640;
            display: block;
            margin-top: 15px;
        }

        select,
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            margin-top: 5px;
            background-color: #f9f9f9;
        }

        .subjects-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px 30px;
            margin-top: 10px;
        }

        .subjects-grid div {
            display: flex;
            flex-direction: column;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 25px;
            background-color: #40739e;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #273c75;
        }

        .message {
            margin-top: 20px;
            text-align: center;
            padding: 12px;
            border-radius: 6px;
            font-size: 14px;
        }

        .success {
            background-color: #dff9fb;
            color: #27ae60;
            border: 1px solid #27ae60;
        }

        .error {
            background-color: #ffcccc;
            color: #c0392b;
            border: 1px solid #c0392b;
        }

        /* Fixed button styling */
        .fixed-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #40739e;
            color: white !important;
            padding: 14px 24px;
            font-weight: bold;
            border-radius: 8px;
            text-decoration: none;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            transition: background-color 0.3s ease;
            z-index: 1000;
            font-size: 16px;
        }

        .fixed-button:hover {
            background-color: #273c75;
        }
    </style>
</head>
<body>



<div class="enrollment-container">
    <div class="enrollment-card">
        <h2>Student Enrollment</h2>

        <?php if (!empty($message)): ?>
            <div class="message <?= htmlspecialchars($messageClass) ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <label for="student_id">Student ID:</label>
            <input type="number" name="student_id" id="student_id" required>

            <label for="first_name">First Name:</label>
            <input type="text" name="first_name" id="first_name" required>

            <label for="middle_name">Middle Name: (optional) </label>
            <input type="text" name="middle_name" id="middle_name">

            <label for="last_name">Last Name:</label>
            <input type="text" name="last_name" id="last_name" required>

            <label for="email">Email:</label>
            <input type="text" name="email" id="email" required>

            <label for="contact_number">Contact Number:</label>
            <input type="text" name="contact_number" id="contact_number" required>

            <label for="course_id">Course:</label>
            <select name="course_id" id="course_id" required>
                <option value="">-- Select Course --</option>
                <?php while ($row = $courses->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($row['CourseID']) ?>">
                        <?= htmlspecialchars($row['CourseName']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <div class="subjects-grid">
                <?php
                $subjectOptions = "";
                if ($subjects && $subjects->num_rows > 0) {
                    while ($row = $subjects->fetch_assoc()) {
                        $sid = htmlspecialchars($row['subject_id']);
                        $sname = htmlspecialchars($row['subject_name']);
                        $subjectOptions .= "<option value='$sid'>$sname</option>";
                    }
                }

                for ($i = 1; $i <= 8; $i++) {
                    echo "<div>";
                    echo "<label for='subject$i'>Subject $i:</label>";
                    echo "<select name='subject$i' id='subject$i' required>";
                    echo "<option value=''>-- Select Subject --</option>";
                    echo $subjectOptions;
                    echo "</select>";
                    echo "</div>";
                }
                ?>
            </div>

            <label for="semester">Semester:</label>
            <input type="text" name="semester" id="semester" placeholder="e.g. 1st, 2nd" required>

            <label for="academic_year">Academic Year:</label>
            <input type="text" name="academic_year" id="academic_year" placeholder="e.g. 2024-2025" required>

            <button type="submit">Enroll Now</button>
        </form>
    </div>
</div>

<!-- Fixed button always visible -->
<a href="view_enrollments.php" class="fixed-button">View All Enrollments</a>

<script>
const selects = document.querySelectorAll("select[name^='subject']");
selects.forEach(select => {
    select.addEventListener("change", () => {
        const selectedValues = new Set();
        let duplicates = false;

        selects.forEach(s => {
            if (s.value) {
                if (selectedValues.has(s.value)) {
                    duplicates = true;
                    s.value = "";
                } else {
                    selectedValues.add(s.value);
                }
            }
        });

        if (duplicates) {
            alert("You cannot select the same subject more than once.");
        }
    });
});
</script>

</body>
</html>

<?php $conn->close(); ?>
