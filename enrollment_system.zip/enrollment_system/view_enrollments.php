<?php
// Connect to database
$conn = new mysqli("localhost", "root", "", "enrollment_system_1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch enrollments with joined data
$sql = "
SELECT 
    e.EnrollmentID,
    p.student_id,
    p.first_name,
    p.middle_name,
    p.last_name,
    p.email,
    p.contact_number,
    c.CourseName,
    e.Semester,
    e.AcademicYear
FROM ENROLLMENT e
JOIN PROFILES p ON e.StudentID = p.student_id
JOIN COURSE c ON e.CourseID = c.CourseID
ORDER BY e.EnrollmentID DESC
";

$result = $conn->query($sql);

// Function to get subjects for an enrollment
function getSubjects($conn, $enrollmentID) {
    $stmt = $conn->prepare("
        SELECT s.subject_name 
        FROM ENROLLMENT_SUBJECTS es
        JOIN SUBJECTS s ON es.subject_id = s.subject_id
        WHERE es.enrollment_id = ?
    ");
    $stmt->bind_param("i", $enrollmentID);
    $stmt->execute();
    $res = $stmt->get_result();
    $subjects = [];
    while ($row = $res->fetch_assoc()) {
        $subjects[] = $row['subject_name'];
    }
    $stmt->close();
    return $subjects;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Enrollments</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            padding: 20px;
            background: #f7f9fc;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px 12px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background: #40739e;
            color: white;
        }
        h2 {
            color: #2f3640;
        }
        .back-btn {
            display: inline-block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background: #40739e;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
        }
        .back-btn:hover {
            background: #273c75;
        }

        /* Subjects list styling */
        .subject-list {
            list-style-type: disc;
            padding-left: 20px;
            margin: 0;
            max-height: 120px;    /* limit height */
            overflow-y: auto;     /* scroll if too tall */
            background: #f0f4f8;
            border-radius: 4px;
            font-size: 0.9rem;
            color: #333;
        }
        .subject-list li {
            margin-bottom: 4px;
        }
    </style>
</head>
<body>

<a href="enroll.php" class="back-btn">&larr; Back to Enroll</a>

<h2>All Enrollments</h2>

<?php if ($result && $result->num_rows > 0): ?>
    <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Contact Number</th>
                <th>Course</th>
                <th>Semester</th>
                <th>Academic Year</th>
                <th>Subjects</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): 
                $fullName = $row['first_name'] 
                    . (!empty($row['middle_name']) ? ' ' . $row['middle_name'] : '') 
                    . ' ' . $row['last_name'];
                $subjects = getSubjects($conn, $row['EnrollmentID']);
            ?>
                <tr>
                    <td><?= htmlspecialchars($row['student_id']) ?></td>
                    <td><?= htmlspecialchars($fullName) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['contact_number']) ?></td>
                    <td><?= htmlspecialchars($row['CourseName']) ?></td>
                    <td><?= htmlspecialchars($row['Semester']) ?></td>
                    <td><?= htmlspecialchars($row['AcademicYear']) ?></td>
                    <td>
                        <ul class="subject-list">
                            <?php foreach ($subjects as $subject): ?>
                                <li><?= htmlspecialchars($subject) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No enrollments found.</p>
<?php endif; ?>

<?php $conn->close(); ?>

</body>
</html>
